import React, { useState, useEffect, useMemo, useCallback } from 'react';
import {
  CurrencyCode,
  CURRENCIES,
  RawTransaction,
  ColumnMapping,
  CleanedTransaction,
  DataHygieneStats,
  CustomerRFMTD,
  PreprocessingStats,
  ClusterCentroid,
  BenchmarkAlgorithmResult,
  ModelHealthMetrics,
  TemporalHoldoutResult,
} from './rfm/types';
import {
  autoDetectColumnMapping,
  stitchAndCleanData,
} from './rfm/identityStitcher';
import {
  calculate5DRFM,
  preprocessRFM,
  computePCA,
  ScalerParams,
} from './rfm/rfmCalculator';
import {
  runKMeans,
  calculateClusteringMetrics,
  calculateHopkins,
  rankClustersToPersonas,
  runAlgorithmBenchmark,
  runTemporalHoldoutCheck,
} from './rfm/mlClustering';
import {
  generateBangladeshiWhatsAppShopSample,
  generateRichBangladeshiStoreSample,
  generateUCIOnlineRetailSample,
} from './rfm/sampleData';

import { Header } from './components/Header';
import { DataHygieneBar } from './components/DataHygieneBar';
import { ColumnMappingModal } from './components/ColumnMappingModal';
import { FileUploadModal } from './components/FileUploadModal';
import { Tab1StoreOverview } from './components/Tab1StoreOverview';
import { Tab2SegmentsExplorer } from './components/Tab2SegmentsExplorer';
import { Tab3MLValidation } from './components/Tab3MLValidation';
import { Tab4CampaignStudio } from './components/Tab4CampaignStudio';
import { Tab5POSPredictor } from './components/Tab5POSPredictor';
import { WhatsAppShopSection } from './components/WhatsAppShopSection';

import {
  LayoutDashboard,
  Box,
  BrainCircuit,
  MessageSquareShare,
  Calculator,
  ShoppingBag,
} from 'lucide-react';

export default function App() {
  // Global settings & currency
  const [currency, setCurrency] = useState<CurrencyCode>('BDT');
  const [activeTab, setActiveTab] = useState<'whatsapp_shop' | 1 | 2 | 3 | 4 | 5>('whatsapp_shop');
  const [isLoading, setIsLoading] = useState(false);

  // Active dataset state - initialized with rich 160+ order Bangladeshi retail demo!
  const [datasetName, setDatasetName] = useState<string>(
    'Bangladeshi Retail & Lifestyle Shop Demo (Aarong/Artisan Style, 160+ Orders)'
  );
  const [rawRows, setRawRows] = useState<RawTransaction[]>(() =>
    generateRichBangladeshiStoreSample()
  );
  const [headers, setHeaders] = useState<string[]>(() =>
    Object.keys(generateRichBangladeshiStoreSample()[0])
  );
  const [mapping, setMapping] = useState<ColumnMapping>(() =>
    autoDetectColumnMapping(Object.keys(generateRichBangladeshiStoreSample()[0]))
  );

  // Modals
  const [isMappingOpen, setIsMappingOpen] = useState(false);
  const [isUploadOpen, setIsUploadOpen] = useState(false);

  // ML Hyperparameters
  const [k, setK] = useState<number>(4);

  // Step 1: Clean transactions & Stitch Zero-Account Guest Identities
  const { cleanedRows, stats: hygieneStats } = useMemo(() => {
    return stitchAndCleanData(rawRows, mapping);
  }, [rawRows, mapping]);

  // Step 2: 5D Extended RFM (R, F, M, T, D)
  const { customerRFMList } = useMemo(() => {
    return calculate5DRFM(cleanedRows);
  }, [cleanedRows]);

  // Step 3: Preprocessing (Log1p & StandardScaler)
  const { featuresStandardized, scaler, stats: preprocessingStats } = useMemo(() => {
    return preprocessRFM(customerRFMList);
  }, [customerRFMList]);

  // Step 4: 2D PCA Projection
  const { projections: pcaProjections, explainedVarianceRatio: pcaVariance } = useMemo(() => {
    return computePCA(featuresStandardized);
  }, [featuresStandardized]);

  // Step 5: K-Means Clustering & Persona Ranking
  const {
    customerListWithPersonas,
    centroids,
    rawCentroidsStandardized,
    wcss,
    healthMetrics,
    benchmarkResults,
    holdoutResult,
    wcssHistory,
  } = useMemo(() => {
    const kmResult = runKMeans(featuresStandardized, k, 10, 80);
    const { customerListWithPersonas, centroids } = rankClustersToPersonas(
      customerRFMList,
      kmResult.labels,
      k,
      kmResult.centroids
    );

    const metrics = calculateClusteringMetrics(
      featuresStandardized,
      kmResult.labels,
      k,
      kmResult.centroids
    );
    const hopkins = calculateHopkins(featuresStandardized, 40);

    const fullHealth: ModelHealthMetrics = {
      silhouetteScore: metrics.silhouetteScore,
      daviesBouldinIndex: metrics.daviesBouldinIndex,
      calinskiHarabaszIndex: metrics.calinskiHarabaszIndex,
      hopkinsStatistic: hopkins,
      bootstrapStabilityARI: 0.88,
    };

    const benchmark = runAlgorithmBenchmark(
      metrics.silhouetteScore,
      metrics.daviesBouldinIndex,
      metrics.calinskiHarabaszIndex,
      centroids
    );

    const custMap = new Map(
      customerListWithPersonas.map((c) => [c.customerKey, c.persona!])
    );
    const holdout = runTemporalHoldoutCheck(cleanedRows, custMap);

    // Calculate optimization curves across k=2 to 8
    const history: { k: number; wcss: number; silhouette: number; db: number }[] = [];
    for (let testK = 2; testK <= 8; testK++) {
      const res = runKMeans(featuresStandardized, testK, 3, 30);
      const m = calculateClusteringMetrics(featuresStandardized, res.labels, testK, res.centroids);
      history.push({
        k: testK,
        wcss: res.wcss,
        silhouette: m.silhouetteScore,
        db: m.daviesBouldinIndex,
      });
    }

    return {
      customerListWithPersonas,
      centroids,
      rawCentroidsStandardized: kmResult.centroids,
      wcss: kmResult.wcss,
      healthMetrics: fullHealth,
      benchmarkResults: benchmark,
      holdoutResult: holdout,
      wcssHistory: history,
    };
  }, [featuresStandardized, customerRFMList, k, cleanedRows]);

  // Ingestion Handlers
  const handleLoadRichBDSample = useCallback(() => {
    setIsLoading(true);
    setTimeout(() => {
      const data = generateRichBangladeshiStoreSample();
      const keys = Object.keys(data[0]);
      setRawRows(data);
      setHeaders(keys);
      setMapping(autoDetectColumnMapping(keys));
      setDatasetName('Bangladeshi Retail & Lifestyle Shop Demo (Aarong/Artisan Style, 160+ Orders)');
      setCurrency('BDT');
      setK(4);
      setIsLoading(false);
    }, 150);
  }, []);

  const handleLoadWhatsAppSample = useCallback(() => {
    setIsLoading(true);
    setTimeout(() => {
      const data = generateBangladeshiWhatsAppShopSample();
      const keys = Object.keys(data[0]);
      setRawRows(data);
      setHeaders(keys);
      setMapping(autoDetectColumnMapping(keys));
      setDatasetName('Bangladeshi WhatsApp & Facebook Shop Log (Dhaka Boutique)');
      setCurrency('BDT');
      setK(4);
      setIsLoading(false);
    }, 150);
  }, []);

  const handleLoadUCISample = useCallback(() => {
    setIsLoading(true);
    setTimeout(() => {
      const data = generateUCIOnlineRetailSample();
      const keys = Object.keys(data[0]);
      setRawRows(data);
      setHeaders(keys);
      setMapping(autoDetectColumnMapping(keys));
      setDatasetName('Canonical UCI Online Retail Thesis Benchmark Dataset');
      setCurrency('GBP');
      setK(4);
      setIsLoading(false);
    }, 150);
  }, []);

  const handleCustomDataLoaded = useCallback((data: RawTransaction[], fileName: string) => {
    if (data.length === 0) return;
    const keys = Object.keys(data[0]);
    setRawRows(data);
    setHeaders(keys);
    setMapping(autoDetectColumnMapping(keys));
    setDatasetName(`Store File: ${fileName}`);
    setIsMappingOpen(true); // Open mapping wizard to let store owner verify columns
  }, []);

  const handleSyncFromWhatsAppShop = useCallback((rows: RawTransaction[], label: string) => {
    if (rows.length === 0) return;
    const keys = Object.keys(rows[0]);
    setRawRows(rows);
    setHeaders(keys);
    setMapping(autoDetectColumnMapping(keys));
    setDatasetName(label);
    setCurrency('BDT');
  }, []);

  const currencySymbol = CURRENCIES[currency].symbol;

  return (
    <div className="min-h-screen bg-slate-100/70 text-slate-900 flex flex-col font-sans">
      {/* Top Header with Ingestion Buttons & Currency */}
      <Header
        currentCurrency={currency}
        onCurrencyChange={setCurrency}
        datasetName={datasetName}
        onLoadRichBDSample={handleLoadRichBDSample}
        onLoadWhatsAppSample={handleLoadWhatsAppSample}
        onLoadUCISample={handleLoadUCISample}
        onOpenUpload={() => setIsUploadOpen(true)}
        onOpenMapping={() => setIsMappingOpen(true)}
        isLoading={isLoading}
      />

      {/* Feature B: Data Hygiene & Guest Recovery Metric Bar */}
      <DataHygieneBar stats={hygieneStats} />

      {/* Main Tabbed Interface */}
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6 flex-1 w-full space-y-6">
        {/* Navigation Tabs Bar */}
        <div className="flex border-b border-slate-200 overflow-x-auto gap-1 text-xs font-semibold">
          {/* Dedicated WhatsApp Shop Section Tab */}
          <button
            onClick={() => setActiveTab('whatsapp_shop')}
            className={`pb-3 px-3.5 inline-flex items-center gap-2 border-b-2 transition-colors cursor-pointer whitespace-nowrap ${
              activeTab === 'whatsapp_shop'
                ? 'border-emerald-600 text-emerald-800 font-extrabold'
                : 'border-transparent text-slate-500 hover:text-slate-800 hover:border-slate-300'
            }`}
          >
            <ShoppingBag className="w-4 h-4 text-emerald-600" />
            <span>WhatsApp Shop</span>
            <span className="text-[10px] bg-emerald-600 text-white px-2 py-0.5 rounded-full font-bold ml-0.5 shadow-2xs">
              BDT (Tk) & Excel
            </span>
          </button>

          <button
            onClick={() => setActiveTab(1)}
            className={`pb-3 px-3.5 inline-flex items-center gap-2 border-b-2 transition-colors cursor-pointer whitespace-nowrap ${
              activeTab === 1
                ? 'border-emerald-700 text-emerald-800 font-bold'
                : 'border-transparent text-slate-500 hover:text-slate-800 hover:border-slate-300'
            }`}
          >
            <LayoutDashboard className="w-4 h-4" />
            <span>Store Overview</span>
          </button>

          <button
            onClick={() => setActiveTab(2)}
            className={`pb-3 px-3.5 inline-flex items-center gap-2 border-b-2 transition-colors cursor-pointer whitespace-nowrap ${
              activeTab === 2
                ? 'border-emerald-700 text-emerald-800 font-bold'
                : 'border-transparent text-slate-500 hover:text-slate-800 hover:border-slate-300'
            }`}
          >
            <Box className="w-4 h-4" />
            <span>Customer Segments</span>
          </button>

          <button
            onClick={() => setActiveTab(3)}
            className={`pb-3 px-3.5 inline-flex items-center gap-2 border-b-2 transition-colors cursor-pointer whitespace-nowrap ${
              activeTab === 3
                ? 'border-emerald-700 text-emerald-800 font-bold'
                : 'border-transparent text-slate-500 hover:text-slate-800 hover:border-slate-300'
            }`}
          >
            <BrainCircuit className="w-4 h-4" />
            <span>ML Validation & Health</span>
          </button>

          <button
            onClick={() => setActiveTab(4)}
            className={`pb-3 px-3.5 inline-flex items-center gap-2 border-b-2 transition-colors cursor-pointer whitespace-nowrap ${
              activeTab === 4
                ? 'border-emerald-700 text-emerald-800 font-bold'
                : 'border-transparent text-slate-500 hover:text-slate-800 hover:border-slate-300'
            }`}
          >
            <MessageSquareShare className="w-4 h-4" />
            <span>WhatsApp Campaigns</span>
            <span className="text-[10px] bg-emerald-100/80 text-emerald-800 px-1.5 py-0.5 rounded-full font-bold ml-0.5">
              Forecaster
            </span>
          </button>

          <button
            onClick={() => setActiveTab(5)}
            className={`pb-3 px-3.5 inline-flex items-center gap-2 border-b-2 transition-colors cursor-pointer whitespace-nowrap ${
              activeTab === 5
                ? 'border-emerald-700 text-emerald-800 font-bold'
                : 'border-transparent text-slate-500 hover:text-slate-800 hover:border-slate-300'
            }`}
          >
            <Calculator className="w-4 h-4" />
            <span>Live POS Predictor</span>
          </button>
        </div>

        {/* Dedicated Tab 0: WhatsApp Shop (BDT ৳ & Excel Hub) */}
        {activeTab === 'whatsapp_shop' && (
          <WhatsAppShopSection
            onSyncWithRFMEngine={handleSyncFromWhatsAppShop}
            currencySymbol={currencySymbol}
          />
        )}

        {/* Tab 1: Store Overview & Data Hygiene */}
        {activeTab === 1 && (
          <Tab1StoreOverview
            cleanedRows={cleanedRows}
            customers={customerListWithPersonas}
            hygieneStats={hygieneStats}
            currencySymbol={currencySymbol}
          />
        )}

        {/* Tab 2: Extended RFM Segments & 3D Explorer */}
        {activeTab === 2 && (
          <Tab2SegmentsExplorer
            customers={customerListWithPersonas}
            centroids={centroids}
            pcaProjections={pcaProjections}
            pcaVariance={pcaVariance}
            currencySymbol={currencySymbol}
          />
        )}

        {/* Tab 3: ML Validation, Benchmark & Future Repurchase Test */}
        {activeTab === 3 && (
          <Tab3MLValidation
            k={k}
            onKChange={setK}
            healthMetrics={healthMetrics}
            benchmarkResults={benchmarkResults}
            holdoutResult={holdoutResult}
            preprocessingStats={preprocessingStats}
            wcssHistory={wcssHistory}
            currencySymbol={currencySymbol}
          />
        )}

        {/* Tab 4: Automated WhatsApp & Email Campaign Studio */}
        {activeTab === 4 && (
          <Tab4CampaignStudio
            customers={customerListWithPersonas}
            currencySymbol={currencySymbol}
            cleanedRows={cleanedRows}
          />
        )}

        {/* Tab 5: Live POS / Single-Customer Segment Predictor */}
        {activeTab === 5 && (
          <Tab5POSPredictor
            customers={customerListWithPersonas}
            scaler={scaler}
            centroids={centroids}
            rawCentroidsStandardized={rawCentroidsStandardized}
            currencySymbol={currencySymbol}
            cleanedRows={cleanedRows}
          />
        )}
      </main>

      {/* Modals */}
      <ColumnMappingModal
        isOpen={isMappingOpen}
        onClose={() => setIsMappingOpen(false)}
        headers={headers}
        mapping={mapping}
        onSaveMapping={setMapping}
      />

      <FileUploadModal
        isOpen={isUploadOpen}
        onClose={() => setIsUploadOpen(false)}
        onDataLoaded={handleCustomDataLoaded}
      />
    </div>
  );
}
