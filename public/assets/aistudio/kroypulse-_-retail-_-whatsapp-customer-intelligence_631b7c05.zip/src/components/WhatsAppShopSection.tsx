import React, { useState, useMemo, useRef } from 'react';
import * as XLSX from 'xlsx';
import Papa from 'papaparse';
import {
  WhatsAppShopOrder,
  WhatsAppShopKPIs,
  calculateWhatsAppShopKPIs,
  downloadWhatsAppShopExcelTemplate,
  buildWhatsAppChatUrl,
  BANGLADESHI_WHATSAPP_SHOP_ORDERS,
  convertWhatsAppShopOrdersToRawRows,
} from '../data/bangladeshiWhatsAppShopData';
import { RawTransaction, CustomerRFMTD } from '../rfm/types';
import {
  generateCustomerRecommendation,
  BANGLADESHI_CATALOG,
  CustomerRecommendationProfile,
  ProductRecommendation,
} from '../rfm/recommendationEngine';
import {
  Download,
  Upload,
  MessageSquare,
  PhoneCall,
  ShieldAlert,
  CheckCircle2,
  Clock,
  Truck,
  RotateCcw,
  Sparkles,
  Search,
  Filter,
  ExternalLink,
  Send,
  FileSpreadsheet,
  ArrowRight,
  TrendingUp,
  AlertTriangle,
  Copy,
  Check,
  Building2,
  Users,
  WalletCards,
  Gift,
  Tag,
  Zap,
} from 'lucide-react';

interface WhatsAppShopSectionProps {
  onSyncWithRFMEngine: (rawRows: RawTransaction[], datasetLabel: string) => void;
  currencySymbol?: string;
}

export const WhatsAppShopSection: React.FC<WhatsAppShopSectionProps> = ({
  onSyncWithRFMEngine,
  currencySymbol = '৳',
}) => {
  // View mode: Orders Ledger vs AI Personalized Offers Studio
  const [viewMode, setViewMode] = useState<'orders' | 'personalized_offers'>('orders');

  // Store orders in local state
  const [orders, setOrders] = useState<WhatsAppShopOrder[]>(() => [
    ...BANGLADESHI_WHATSAPP_SHOP_ORDERS,
  ]);
  const [activeDatasetLabel, setActiveDatasetLabel] = useState<string>(
    'Dhakaiya Heritage Crafts & Boutique (120+ Orders · BDT ৳)'
  );

  // Search & Filter state
  const [searchQuery, setSearchQuery] = useState('');
  const [paymentFilter, setPaymentFilter] = useState<string>('ALL');
  const [statusFilter, setStatusFilter] = useState<string>('ALL');
  const [districtFilter, setDistrictFilter] = useState<string>('ALL');
  const [sortBy, setSortBy] = useState<'date_desc' | 'date_asc' | 'amount_desc' | 'repeat_first'>('date_desc');

  // WhatsApp Messaging Modal State
  const [selectedOrderForChat, setSelectedOrderForChat] = useState<WhatsAppShopOrder | null>(null);
  const [chatTemplate, setChatTemplate] = useState<
    'order_confirm' | 'courier_dispatch' | 'eid_offer' | 'review_request' | 'personalized_offer'
  >('order_confirm');
  const [messageLang, setMessageLang] = useState<'bn' | 'en'>('en');
  const [copiedLink, setCopiedLink] = useState(false);
  const [syncSuccessToast, setSyncSuccessToast] = useState(false);

  // File Upload Handling
  const fileInputRef = useRef<HTMLInputElement | null>(null);
  const [uploadError, setUploadError] = useState<string | null>(null);

  const [isUploading, setIsUploading] = useState(false);

  // Calculate KPIs
  const kpis: WhatsAppShopKPIs = useMemo(() => {
    return calculateWhatsAppShopKPIs(orders);
  }, [orders]);

  // Customer repeat map for quick repeat status badge
  const repeatPhoneSet = useMemo(() => {
    const counts = new Map<string, number>();
    orders.forEach((o) => {
      const p = o.whatsappPhone ? o.whatsappPhone.replace(/[^\d]/g, '') : o.customerName;
      counts.set(p, (counts.get(p) || 0) + 1);
    });
    const repeats = new Set<string>();
    counts.forEach((c, p) => {
      if (c > 1) repeats.add(p);
    });
    return repeats;
  }, [orders]);

  // Pre-calculate Next-Best Product and Personalized Offer for each WhatsApp Shop customer
  const customerRecs = useMemo(() => {
    type RecEntry = {
      profile: CustomerRecommendationProfile;
      orders: WhatsAppShopOrder[];
      totalSpend: number;
      customerName: string;
      whatsappPhone: string;
    };
    const map = new Map<string, RecEntry>();

    orders.forEach((o) => {
      const key = o.whatsappPhone ? o.whatsappPhone.replace(/[^\d]/g, '') : o.customerName;
      const entry: RecEntry = map.get(key) || {
        profile: {} as any,
        orders: [] as WhatsAppShopOrder[],
        totalSpend: 0,
        customerName: o.customerName,
        whatsappPhone: o.whatsappPhone,
      };
      entry.orders.push(o);
      entry.totalSpend += o.totalAmountBDT;
      map.set(key, entry);
    });

    map.forEach((entry, key) => {
      const isRepeat = entry.orders.length > 1;
      const persona =
        entry.totalSpend >= 10000 || entry.orders.length >= 4
          ? 'Champions (VIP Loyalists)'
          : isRepeat
          ? 'Loyal & Promising Regulars'
          : entry.orders[0]?.deliveryStatus === 'RTO / Returned'
          ? 'Hibernating / Lost Guests'
          : 'High-Potential / At-Risk Guests';

      const mockRFM: CustomerRFMTD = {
        customerKey: entry.customerName || key,
        phone: entry.orders[0]?.whatsappPhone,
        isGuest: true,
        firstPurchaseDate: new Date(entry.orders[entry.orders.length - 1].orderDate),
        lastPurchaseDate: new Date(entry.orders[0].orderDate),
        recency: 10,
        frequency: entry.orders.length,
        monetary: entry.totalSpend,
        avgOrderValue: entry.totalSpend / entry.orders.length,
        interPurchaseTime: 30,
        basketDepth: entry.orders.length,
        isSinglePurchase: !isRepeat,
        persona,
      };

      const pastItems = entry.orders.map((o) => o.items);
      const profile = generateCustomerRecommendation(
        mockRFM,
        pastItems,
        BANGLADESHI_CATALOG,
        currencySymbol
      );
      entry.profile = profile;
    });

    return map;
  }, [orders, currencySymbol]);


  // Unique districts for filter dropdown
  const districtList = useMemo(() => {
    const set = new Set<string>();
    orders.forEach((o) => {
      if (o.deliveryDistrict) set.add(o.deliveryDistrict.split('(')[0]?.trim());
    });
    return Array.from(set).sort();
  }, [orders]);

  // Filtered & Sorted orders
  const filteredOrders = useMemo(() => {
    return orders
      .filter((o) => {
        // Search query
        if (searchQuery.trim()) {
          const q = searchQuery.toLowerCase();
          const match =
            o.customerName.toLowerCase().includes(q) ||
            o.whatsappPhone.toLowerCase().includes(q) ||
            o.orderId.toLowerCase().includes(q) ||
            o.items.toLowerCase().includes(q) ||
            o.deliveryDistrict.toLowerCase().includes(q) ||
            (o.trackingNumber && o.trackingNumber.toLowerCase().includes(q));
          if (!match) return false;
        }

        // Payment filter
        if (paymentFilter !== 'ALL') {
          if (!o.paymentMethod.toLowerCase().includes(paymentFilter.toLowerCase())) {
            return false;
          }
        }

        // Status filter
        if (statusFilter !== 'ALL') {
          if (o.deliveryStatus !== statusFilter) return false;
        }

        // District filter
        if (districtFilter !== 'ALL') {
          if (!o.deliveryDistrict.toLowerCase().includes(districtFilter.toLowerCase())) {
            return false;
          }
        }

        return true;
      })
      .sort((a, b) => {
        if (sortBy === 'date_desc') {
          return new Date(b.orderDate).getTime() - new Date(a.orderDate).getTime();
        }
        if (sortBy === 'date_asc') {
          return new Date(a.orderDate).getTime() - new Date(b.orderDate).getTime();
        }
        if (sortBy === 'amount_desc') {
          return b.totalAmountBDT - a.totalAmountBDT;
        }
        if (sortBy === 'repeat_first') {
          const aKey = a.whatsappPhone.replace(/[^\d]/g, '');
          const bKey = b.whatsappPhone.replace(/[^\d]/g, '');
          const aRepeat = repeatPhoneSet.has(aKey) ? 1 : 0;
          const bRepeat = repeatPhoneSet.has(bKey) ? 1 : 0;
          return bRepeat - aRepeat;
        }
        return 0;
      });
  }, [orders, searchQuery, paymentFilter, statusFilter, districtFilter, sortBy, repeatPhoneSet]);

  // Handle Loading Bangladeshi Demo
  const handleLoadBangladeshiDemo = () => {
    setOrders([...BANGLADESHI_WHATSAPP_SHOP_ORDERS]);
    setActiveDatasetLabel('Dhakaiya Heritage Crafts & Boutique (120+ Orders · BDT ৳)');
    setUploadError(null);
  };

  // Handle Excel or CSV file upload
  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    setUploadError(null);
    setIsUploading(true);
    const fileName = file.name;
    const ext = fileName.split('.').pop()?.toLowerCase();

    if (ext === 'xlsx' || ext === 'xls') {
      const reader = new FileReader();
      reader.onload = (evt) => {
        try {
          const buffer = evt.target?.result as ArrayBuffer;
          const workbook = XLSX.read(buffer, { type: 'array' });
          const firstSheetName = workbook.SheetNames[0];
          const sheet = workbook.Sheets[firstSheetName];
          const rawData = XLSX.utils.sheet_to_json<any>(sheet, { defval: '' });

          if (rawData.length === 0) {
            setUploadError('The uploaded Excel sheet contains no order rows.');
            setIsUploading(false);
            return;
          }

          // Map raw rows into WhatsAppShopOrder format
          const mappedOrders: WhatsAppShopOrder[] = rawData.map((row, idx) => {
            const findKey = (candidates: string[]) => {
              const keys = Object.keys(row);
              for (const c of candidates) {
                const found = keys.find((k) =>
                  k.toLowerCase().replace(/[^a-z0-9]/g, '').includes(c.toLowerCase().replace(/[^a-z0-9]/g, ''))
                );
                if (found) return row[found];
              }
              return '';
            };

            const orderId = String(findKey(['orderid', 'invoiceno', 'receipt', 'id']) || `WA-${1000 + idx}`);
            const orderDate = String(findKey(['orderdate', 'invoicedate', 'date', 'createdat']) || new Date().toISOString().slice(0, 10));
            const customerName = String(findKey(['customername', 'name', 'client', 'buyer']) || 'Customer');
            const whatsappPhone = String(findKey(['whatsappphone', 'phone', 'mobile', 'cell', 'contact']) || '');
            const items = String(findKey(['items', 'products', 'productname', 'itemname', 'description']) || 'Store Product');
            const category = String(findKey(['category', 'type', 'dept']) || 'General');
            const quantity = Number(findKey(['quantity', 'qty', 'count'])) || 1;
            const unitPrice = Number(findKey(['unitprice', 'price', 'rate'])) || 1000;
            const totalAmountBDT = Number(findKey(['totalamount', 'totalprice', 'total', 'amount', 'grandtotal'])) || (quantity * unitPrice);

            const rawPayment = String(findKey(['paymentmethod', 'payment', 'method', 'paidvia'])).toLowerCase();
            let paymentMethod: WhatsAppShopOrder['paymentMethod'] = 'Cash on Delivery (COD)';
            if (rawPayment.includes('bkash')) {
              paymentMethod = rawPayment.includes('merchant') ? 'bKash Merchant' : 'bKash Personal';
            } else if (rawPayment.includes('nagad')) {
              paymentMethod = 'Nagad';
            } else if (rawPayment.includes('bank')) {
              paymentMethod = 'Bank Transfer';
            }

            const advancePaidBDT = Number(findKey(['advancepaid', 'advance', 'deposit', 'couriercharge'])) || (paymentMethod.includes('bKash') || paymentMethod.includes('Nagad') ? totalAmountBDT : 150);
            const dueAmountBDT = Math.max(0, totalAmountBDT - advancePaidBDT);
            const deliveryDistrict = String(findKey(['deliverydistrict', 'district', 'area', 'city', 'location']) || 'Dhaka');

            const rawCourier = String(findKey(['courierpartner', 'courier', 'deliverycompany', 'shipping'])).toLowerCase();
            let courierPartner: WhatsAppShopOrder['courierPartner'] = 'Pathao Courier';
            if (rawCourier.includes('steadfast')) courierPartner = 'Steadfast';
            else if (rawCourier.includes('redx')) courierPartner = 'RedX';
            else if (rawCourier.includes('sundarban')) courierPartner = 'Sundarban Courier';
            else if (rawCourier.includes('paperfly')) courierPartner = 'Paperfly';

            const rawStatus = String(findKey(['deliverystatus', 'status', 'orderstatus', 'shippingstatus'])).toLowerCase();
            let deliveryStatus: WhatsAppShopOrder['deliveryStatus'] = 'Delivered';
            if (rawStatus.includes('return') || rawStatus.includes('rto') || rawStatus.includes('cancel')) {
              deliveryStatus = 'RTO / Returned';
            } else if (rawStatus.includes('transit') || rawStatus.includes('shipped') || rawStatus.includes('way')) {
              deliveryStatus = 'In Transit';
            } else if (rawStatus.includes('pending') || rawStatus.includes('process') || rawStatus.includes('confirm')) {
              deliveryStatus = 'Pending Confirmation';
            }

            const trackingNumber = String(findKey(['trackingnumber', 'tracking', 'consignment', 'cnno']) || 'PTH-' + Math.floor(100000 + Math.random() * 900000));
            const customerNotes = String(findKey(['customernotes', 'notes', 'remarks', 'comment']) || '');

            return {
              orderId,
              orderDate,
              customerName,
              whatsappPhone,
              items,
              category,
              quantity,
              unitPrice,
              totalAmountBDT,
              paymentMethod,
              advancePaidBDT,
              dueAmountBDT,
              deliveryDistrict,
              courierPartner,
              deliveryStatus,
              trackingNumber,
              customerNotes,
            };
          });

          setOrders(mappedOrders);
          setActiveDatasetLabel(`Uploaded Excel: ${fileName} (${mappedOrders.length} rows)`);
          setIsUploading(false);
        } catch (err: any) {
          setUploadError(`Failed to parse Excel file: ${err.message || 'Unknown error'}`);
          setIsUploading(false);
        }
      };
      reader.readAsArrayBuffer(file);
    } else {
      // CSV parser
      Papa.parse<any>(file, {
        header: true,
        dynamicTyping: true,
        skipEmptyLines: true,
        complete: (results) => {
          if (!results.data || results.data.length === 0) {
            setUploadError('The uploaded CSV file is empty.');
            setIsUploading(false);
            return;
          }

          const mappedOrders: WhatsAppShopOrder[] = results.data.map((row, idx) => ({
            orderId: String(row['Order ID'] || row.order_id || row.id || `WA-${1000 + idx}`),
            orderDate: String(row['Order Date'] || row.order_date || row.created_at || new Date().toISOString().slice(0, 10)),
            customerName: String(row['Customer Name'] || row.customer_name || row.name || 'Customer'),
            whatsappPhone: String(row['WhatsApp Phone'] || row.whatsapp_phone || row.phone || ''),
            items: String(row['Items / Products'] || row.items || row.product_name || 'Store Product'),
            category: String(row.Category || row.category || 'General'),
            quantity: Number(row.Quantity || row.quantity) || 1,
            unitPrice: Number(row['Unit Price (BDT)'] || row.unit_price) || 1000,
            totalAmountBDT: Number(row['Total Amount (BDT)'] || row.total_price || row.total) || 1000,
            paymentMethod: (row['Payment Method'] || row.payment_method || 'Cash on Delivery (COD)') as any,
            advancePaidBDT: Number(row['Advance Paid (BDT)'] || row.advance_paid) || 150,
            dueAmountBDT: Number(row['Due Amount (BDT)'] || row.due_amount) || 0,
            deliveryDistrict: String(row['Delivery District / Area'] || row.delivery_district || row.district || 'Dhaka'),
            courierPartner: (row['Courier Partner'] || row.courier_partner || 'Pathao Courier') as any,
            deliveryStatus: (row['Delivery Status'] || row.delivery_status || 'Delivered') as any,
            trackingNumber: String(row['Tracking Number'] || row.tracking_number || 'PTH-' + idx),
            customerNotes: String(row['Customer Notes'] || row.notes || ''),
          }));

          setOrders(mappedOrders);
          setActiveDatasetLabel(`Uploaded CSV: ${fileName} (${mappedOrders.length} rows)`);
          setIsUploading(false);
        },
        error: (err) => {
          setUploadError(`Error parsing CSV: ${err.message}`);
          setIsUploading(false);
        },
      });
    }

    // Reset input
    if (fileInputRef.current) fileInputRef.current.value = '';
  };

  // Sync to 5D RFM Engine
  const handlePushToRFM = () => {
    const rawRows = convertWhatsAppShopOrdersToRawRows(orders);
    onSyncWithRFMEngine(rawRows, `WhatsApp Shop Hub · ${activeDatasetLabel}`);
    setSyncSuccessToast(true);
    setTimeout(() => setSyncSuccessToast(false), 3500);
  };

  // Export current filtered list as CSV
  const handleExportFilteredCSV = () => {
    const exportData = filteredOrders.map((o) => ({
      'Order ID': o.orderId,
      'Order Date': o.orderDate,
      'Customer Name': o.customerName,
      'WhatsApp Phone': o.whatsappPhone,
      'Items': o.items,
      'Category': o.category,
      'Total Amount (BDT)': o.totalAmountBDT,
      'Payment Method': o.paymentMethod,
      'Advance Paid (BDT)': o.advancePaidBDT,
      'Due COD (BDT)': o.dueAmountBDT,
      'District': o.deliveryDistrict,
      'Courier': o.courierPartner,
      'Status': o.deliveryStatus,
      'Tracking': o.trackingNumber,
      'Notes': o.customerNotes || '',
    }));

    const csv = Papa.unparse(exportData);
    const blob = new Blob([csv], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.setAttribute('download', `WhatsApp_Shop_Orders_${new Date().toISOString().slice(0, 10)}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  return (
    <div className="space-y-6">
      {/* Top Banner & Control Center */}
      <div className="bg-gradient-to-r from-emerald-900 via-emerald-800 to-teal-900 text-white rounded-2xl p-6 shadow-md border border-emerald-700/50">
        <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-6">
          <div className="space-y-2 max-w-2xl">
            <div className="inline-flex items-center gap-2 bg-emerald-500/20 text-emerald-200 border border-emerald-400/30 px-3 py-1 rounded-full text-xs font-semibold backdrop-blur-xs">
              <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse"></span>
              Dedicated WhatsApp Commerce & Excel Hub · Bangladesh (BDT ৳)
            </div>
            <h2 className="text-2xl font-black tracking-tight text-white flex items-center gap-2">
              <span>WhatsApp Shop Manager</span>
              <span className="text-xs font-semibold px-2 py-0.5 rounded-md bg-emerald-700/80 text-emerald-100 border border-emerald-600">
                F-Commerce Ready
              </span>
            </h2>
            <p className="text-sm text-emerald-100/90 leading-relaxed">
              Tailored for merchants running their business via WhatsApp, Facebook, and Instagram chat.
              Keep your customer and order records in Excel, upload anytime, track bKash vs COD payments,
              prevent courier return losses, and launch 1-click WhatsApp conversations in Bangla & English.
            </p>
          </div>

          {/* Quick Actions */}
          <div className="flex flex-wrap items-center gap-2.5 shrink-0">
            {/* Download Excel Template */}
            <button
              onClick={downloadWhatsAppShopExcelTemplate}
              className="inline-flex items-center gap-2 bg-white text-emerald-900 hover:bg-emerald-50 px-3.5 py-2.5 rounded-xl text-xs font-bold shadow-sm transition-all cursor-pointer border border-emerald-100"
              title="Download standardized .xlsx Excel order tracking template"
            >
              <Download className="w-4 h-4 text-emerald-700" />
              <span>Download Excel Template (.xlsx)</span>
            </button>

            {/* Hidden File Input */}
            <input
              type="file"
              ref={fileInputRef}
              onChange={handleFileUpload}
              accept=".xlsx,.xls,.csv"
              className="hidden"
            />

            {/* Upload Shop Excel Button */}
            <button
              onClick={() => fileInputRef.current?.click()}
              disabled={isUploading}
              className="inline-flex items-center gap-2 bg-emerald-700 hover:bg-emerald-600 text-white px-3.5 py-2.5 rounded-xl text-xs font-bold shadow-sm transition-all cursor-pointer border border-emerald-600"
              title="Upload your WhatsApp shop Excel sheet (.xlsx, .xls, .csv)"
            >
              <Upload className="w-4 h-4 text-emerald-200" />
              <span>{isUploading ? 'Parsing Excel...' : 'Upload Shop Excel (.xlsx)'}</span>
            </button>

            {/* Load Bangladeshi BDT Demo */}
            <button
              onClick={handleLoadBangladeshiDemo}
              className="inline-flex items-center gap-2 bg-emerald-950/60 hover:bg-emerald-950 text-emerald-200 hover:text-white px-3.5 py-2.5 rounded-xl text-xs font-bold transition-all cursor-pointer border border-emerald-600/40"
              title="Load authentic Bangladeshi demo with bKash, Nagad, COD and Pathao data"
            >
              <Sparkles className="w-4 h-4 text-amber-300" />
              <span>Load 🇧🇩 Demo (120+ Orders)</span>
            </button>

            {/* Push to 5D RFM Engine */}
            <button
              onClick={handlePushToRFM}
              className="inline-flex items-center gap-2 bg-amber-500 hover:bg-amber-400 text-slate-950 px-4 py-2.5 rounded-xl text-xs font-extrabold shadow-md transition-all cursor-pointer"
              title="Push current WhatsApp shop data into full 5D RFM segmentation & campaign forecaster"
            >
              <TrendingUp className="w-4 h-4 text-slate-950" />
              <span>Analyze in 5D RFM Engine</span>
              <ArrowRight className="w-3.5 h-3.5" />
            </button>
          </div>
        </div>

        {/* Dataset Label and Feedback */}
        <div className="mt-4 pt-3 border-t border-emerald-800/60 flex flex-wrap items-center justify-between text-xs text-emerald-200/80 gap-2">
          <div className="flex items-center gap-2">
            <span className="text-emerald-300 font-semibold">Active Ledger:</span>
            <span className="bg-emerald-950/80 px-2.5 py-0.5 rounded-md font-mono text-emerald-100 border border-emerald-700/50">
              {activeDatasetLabel}
            </span>
          </div>
          <div className="flex items-center gap-3">
            <span>⚡ {orders.length} total orders parsed</span>
            <span>·</span>
            <span>📱 {kpis.uniqueCustomers} unique WhatsApp contacts</span>
          </div>
        </div>

        {uploadError && (
          <div className="mt-3 p-3 bg-rose-900/60 border border-rose-500/50 rounded-xl text-xs text-rose-200 flex items-center gap-2">
            <AlertTriangle className="w-4 h-4 text-rose-400 shrink-0" />
            <span>{uploadError}</span>
          </div>
        )}

        {syncSuccessToast && (
          <div className="mt-3 p-3 bg-emerald-700 border border-emerald-400 rounded-xl text-xs text-white font-medium flex items-center justify-between animate-fade-in">
            <div className="flex items-center gap-2">
              <CheckCircle2 className="w-4 h-4 text-emerald-200" />
              <span>
                Successfully synced {orders.length} WhatsApp orders to the 5D RFM Engine! Check the Store Overview, Segments, and Campaign Studio tabs.
              </span>
            </div>
            <button
              onClick={() => setSyncSuccessToast(false)}
              className="text-xs text-emerald-200 hover:text-white underline cursor-pointer"
            >
              Dismiss
            </button>
          </div>
        )}
      </div>

      {/* 4 WhatsApp Commerce KPI Cards (BDT ৳) */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        {/* Card 1: Gross Revenue */}
        <div className="bg-white rounded-2xl p-5 border border-slate-200/90 shadow-xs relative overflow-hidden">
          <div className="flex items-center justify-between">
            <span className="text-xs font-bold text-slate-500 uppercase tracking-wider">
              Total Shop Revenue
            </span>
            <div className="w-8 h-8 rounded-lg bg-emerald-50 text-emerald-700 flex items-center justify-center font-bold">
              ৳
            </div>
          </div>
          <div className="mt-2">
            <div className="text-2xl font-black text-slate-900 tracking-tight">
              {currencySymbol} {kpis.totalRevenueBDT.toLocaleString()}
            </div>
            <div className="text-[11px] text-slate-500 mt-1 flex items-center justify-between">
              <span>Avg Order: {currencySymbol} {Math.round(kpis.avgOrderValueBDT).toLocaleString()}</span>
              <span className="font-semibold text-emerald-700">
                Adv: {currencySymbol} {kpis.advanceCollectedBDT.toLocaleString()}
              </span>
            </div>
          </div>
        </div>

        {/* Card 2: WhatsApp Customer Base & Repeat Rate */}
        <div className="bg-white rounded-2xl p-5 border border-slate-200/90 shadow-xs relative overflow-hidden">
          <div className="flex items-center justify-between">
            <span className="text-xs font-bold text-slate-500 uppercase tracking-wider">
              WhatsApp Contacts
            </span>
            <div className="w-8 h-8 rounded-lg bg-teal-50 text-teal-700 flex items-center justify-center">
              <Users className="w-4 h-4" />
            </div>
          </div>
          <div className="mt-2">
            <div className="text-2xl font-black text-slate-900 tracking-tight">
              {kpis.uniqueCustomers}{' '}
              <span className="text-xs font-semibold text-slate-400">clients</span>
            </div>
            <div className="text-[11px] text-slate-500 mt-1 flex items-center justify-between">
              <span>Repeat Rate: <strong className="text-teal-700">{kpis.repeatCustomerRatePct.toFixed(1)}%</strong></span>
              <span className="bg-teal-50 text-teal-800 text-[10px] font-bold px-1.5 py-0.5 rounded-sm">
                {kpis.repeatCustomers} VIPs
              </span>
            </div>
          </div>
        </div>

        {/* Card 3: Prepaid vs COD Cash Flow Breakdown */}
        <div className="bg-white rounded-2xl p-5 border border-slate-200/90 shadow-xs relative overflow-hidden">
          <div className="flex items-center justify-between">
            <span className="text-xs font-bold text-slate-500 uppercase tracking-wider">
              Prepaid (bKash/Nagad)
            </span>
            <div className="w-8 h-8 rounded-lg bg-indigo-50 text-indigo-700 flex items-center justify-center">
              <WalletCards className="w-4 h-4" />
            </div>
          </div>
          <div className="mt-2">
            <div className="text-2xl font-black text-indigo-950 tracking-tight flex items-baseline gap-2">
              <span>{kpis.prepaidSharePct.toFixed(0)}%</span>
              <span className="text-xs font-normal text-slate-500">
                ({currencySymbol} {kpis.prepaidRevenueBDT.toLocaleString()})
              </span>
            </div>
            <div className="mt-2 w-full bg-slate-100 rounded-full h-1.5 overflow-hidden flex">
              <div
                className="bg-emerald-500 h-full"
                style={{ width: `${kpis.prepaidSharePct}%` }}
                title="Prepaid via bKash, Nagad or Bank"
              />
              <div
                className="bg-amber-400 h-full"
                style={{ width: `${100 - kpis.prepaidSharePct}%` }}
                title="Cash on Delivery (COD)"
              />
            </div>
            <div className="text-[10px] text-slate-500 mt-1 flex justify-between">
              <span>bKash/Nagad: {kpis.prepaidCount} orders</span>
              <span>COD: {kpis.codCount} orders</span>
            </div>
          </div>
        </div>

        {/* Card 4: COD RTO Shield & Courier Loss Rate */}
        <div className="bg-white rounded-2xl p-5 border border-slate-200/90 shadow-xs relative overflow-hidden">
          <div className="flex items-center justify-between">
            <span className="text-xs font-bold text-slate-500 uppercase tracking-wider">
              COD Return (RTO) Rate
            </span>
            <div className={`w-8 h-8 rounded-lg flex items-center justify-center ${kpis.rtoCount > 0 ? 'bg-rose-50 text-rose-600' : 'bg-emerald-50 text-emerald-600'}`}>
              <RotateCcw className="w-4 h-4" />
            </div>
          </div>
          <div className="mt-2">
            <div className="text-2xl font-black text-slate-900 tracking-tight flex items-baseline gap-2">
              <span className={kpis.rtoRatePct > 5 ? 'text-rose-600' : 'text-emerald-700'}>
                {kpis.rtoRatePct.toFixed(1)}%
              </span>
              <span className="text-xs font-normal text-slate-500">
                ({kpis.rtoCount} parcels)
              </span>
            </div>
            <div className="text-[11px] text-slate-500 mt-1 flex items-center justify-between">
              <span>Lost Value: {currencySymbol} {kpis.rtoLostRevenueBDT.toLocaleString()}</span>
              <span className="text-[10px] font-bold text-rose-700 bg-rose-50 px-1.5 py-0.5 rounded-sm">
                Shield Active
              </span>
            </div>
          </div>
        </div>
      </div>

      {/* Bangladeshi Merchant Pro-Tip: COD RTO Loss Shield */}
      <div className="bg-amber-50 border border-amber-200/80 rounded-2xl p-4 flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
        <div className="flex items-start gap-3">
          <div className="p-2 bg-amber-100 text-amber-800 rounded-xl shrink-0 mt-0.5">
            <ShieldAlert className="w-5 h-5" />
          </div>
          <div className="text-xs">
            <h4 className="font-bold text-amber-900">
              Bangladeshi F-Commerce Risk Shield: Reducing Courier Return-to-Origin (RTO)
            </h4>
            <p className="text-amber-800/90 mt-0.5 leading-relaxed">
              Couriers like Steadfast, Pathao, and RedX charge ৳100 - ৳180 return fee when buyers reject COD deliveries at doorstep.
              Always require a <strong>৳150 - ৳200 advance delivery fee via bKash/Nagad</strong> before parcel dispatch for outside-Dhaka orders.
              Click the green WhatsApp button below to send pre-filled confirmation requests.
            </p>
          </div>
        </div>
        <div className="shrink-0 flex items-center gap-2">
          <button
            onClick={() => {
              setStatusFilter('RTO / Returned');
            }}
            className="text-xs font-bold text-amber-900 bg-amber-200/70 hover:bg-amber-200 px-3 py-1.5 rounded-lg transition-colors cursor-pointer"
          >
            Filter RTO Parcels ({kpis.rtoCount})
          </button>
        </div>
      </div>

      {/* Sub-view Switcher: Orders Ledger vs AI Personalized Offers & Suggestions Studio */}
      <div className="flex items-center gap-2 border-b border-slate-200">
        <button
          onClick={() => setViewMode('orders')}
          className={`pb-3 px-4 font-bold text-xs inline-flex items-center gap-2 border-b-2 transition-all cursor-pointer ${
            viewMode === 'orders'
              ? 'border-emerald-600 text-emerald-800'
              : 'border-transparent text-slate-500 hover:text-slate-800'
          }`}
        >
          <FileSpreadsheet className="w-4 h-4 text-emerald-600" />
          <span>WhatsApp Orders Ledger ({orders.length})</span>
        </button>

        <button
          onClick={() => setViewMode('personalized_offers')}
          className={`pb-3 px-4 font-bold text-xs inline-flex items-center gap-2 border-b-2 transition-all cursor-pointer ${
            viewMode === 'personalized_offers'
              ? 'border-emerald-600 text-emerald-800'
              : 'border-transparent text-slate-500 hover:text-slate-800'
          }`}
        >
          <Sparkles className="w-4 h-4 text-amber-500" />
          <span>✨ AI Personalized Offers & Suggestions ({customerRecs.size} Shoppers)</span>
          <span className="text-[10px] bg-amber-100 text-amber-900 px-1.5 py-0.5 rounded-full font-extrabold">
            Next-Best Product
          </span>
        </button>
      </div>

      {viewMode === 'orders' ? (
        /* Orders Ledger & Customer Directory */
        <div className="bg-white rounded-2xl border border-slate-200/90 shadow-xs overflow-hidden">
          {/* Ledger Header & Toolbar */}
          <div className="p-5 border-b border-slate-200 bg-slate-50/70 space-y-4">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
              <div>
                <h3 className="text-base font-bold text-slate-900 flex items-center gap-2">
                  <FileSpreadsheet className="w-5 h-5 text-emerald-700" />
                  <span>WhatsApp Order Book & Customer Ledger</span>
                  <span className="text-xs font-semibold px-2 py-0.5 rounded-full bg-slate-200 text-slate-700">
                    {filteredOrders.length} orders
                  </span>
                </h3>
                <p className="text-xs text-slate-500 mt-0.5">
                  Real-time tracking of customer name, WhatsApp phone, items, bKash/COD payment, courier and status
                </p>
              </div>

            <div className="flex items-center gap-2">
              <button
                onClick={handleExportFilteredCSV}
                className="inline-flex items-center gap-1.5 px-3 py-1.5 bg-white border border-slate-300 hover:bg-slate-50 text-slate-700 rounded-lg text-xs font-semibold shadow-2xs transition-colors cursor-pointer"
                title="Export currently filtered list as CSV"
              >
                <Download className="w-3.5 h-3.5 text-slate-500" />
                <span>Export Filtered CSV</span>
              </button>
            </div>
          </div>

          {/* Search & Filter Controls */}
          <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 lg:grid-cols-5 gap-3 pt-2">
            {/* Search Input */}
            <div className="relative col-span-1 sm:col-span-2 md:col-span-1 lg:col-span-2">
              <Search className="w-4 h-4 text-slate-400 absolute left-3 top-2.5" />
              <input
                type="text"
                placeholder="Search by customer, phone, item, district, tracking..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="w-full pl-9 pr-3 py-2 bg-white border border-slate-300 rounded-lg text-xs focus:ring-2 focus:ring-emerald-500 focus:outline-hidden"
              />
            </div>

            {/* Payment Method Filter */}
            <div>
              <select
                value={paymentFilter}
                onChange={(e) => setPaymentFilter(e.target.value)}
                className="w-full px-3 py-2 bg-white border border-slate-300 rounded-lg text-xs text-slate-700 focus:ring-2 focus:ring-emerald-500 focus:outline-hidden cursor-pointer"
              >
                <option value="ALL">💳 All Payment Methods</option>
                <option value="bKash">bKash (Merchant & Personal)</option>
                <option value="Nagad">Nagad</option>
                <option value="COD">Cash on Delivery (COD)</option>
                <option value="Bank">Bank Transfer</option>
              </select>
            </div>

            {/* Status Filter */}
            <div>
              <select
                value={statusFilter}
                onChange={(e) => setStatusFilter(e.target.value)}
                className="w-full px-3 py-2 bg-white border border-slate-300 rounded-lg text-xs text-slate-700 focus:ring-2 focus:ring-emerald-500 focus:outline-hidden cursor-pointer"
              >
                <option value="ALL">📦 All Delivery Statuses</option>
                <option value="Delivered">Delivered</option>
                <option value="In Transit">In Transit</option>
                <option value="Pending Confirmation">Pending Confirmation</option>
                <option value="RTO / Returned">RTO / Returned</option>
              </select>
            </div>

            {/* District Filter */}
            <div>
              <select
                value={districtFilter}
                onChange={(e) => setDistrictFilter(e.target.value)}
                className="w-full px-3 py-2 bg-white border border-slate-300 rounded-lg text-xs text-slate-700 focus:ring-2 focus:ring-emerald-500 focus:outline-hidden cursor-pointer"
              >
                <option value="ALL">📍 All Districts ({districtList.length})</option>
                {districtList.map((d) => (
                  <option key={d} value={d}>
                    {d}
                  </option>
                ))}
              </select>
            </div>
          </div>
        </div>

        {/* Orders Table */}
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead className="bg-slate-100 text-slate-600 font-bold uppercase tracking-wider text-[10px] border-b border-slate-200">
              <tr>
                <th className="py-3 px-4">Customer & WhatsApp</th>
                <th className="py-3 px-4">Order & Date</th>
                <th className="py-3 px-4">Items / Products</th>
                <th className="py-3 px-4">Amount & Payment</th>
                <th className="py-3 px-4">Advance / Due</th>
                <th className="py-3 px-4">District & Courier</th>
                <th className="py-3 px-4">Status</th>
                <th className="py-3 px-4 text-right">WhatsApp Action</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-200">
              {filteredOrders.length === 0 ? (
                <tr>
                  <td colSpan={8} className="py-12 text-center text-slate-400">
                    <p className="text-sm font-semibold">No orders found matching your filters</p>
                    <p className="text-xs mt-1">Try clearing your search query or reset filter options.</p>
                  </td>
                </tr>
              ) : (
                filteredOrders.map((order) => {
                  const phoneClean = order.whatsappPhone.replace(/[^\d]/g, '');
                  const isRepeat = repeatPhoneSet.has(phoneClean);

                  return (
                    <tr key={order.orderId} className="hover:bg-slate-50/80 transition-colors">
                      {/* Customer Name & WhatsApp */}
                      <td className="py-3 px-4">
                        <div className="font-bold text-slate-900 flex items-center gap-1.5">
                          <span>{order.customerName}</span>
                          {isRepeat && (
                            <span className="bg-teal-100 text-teal-800 text-[10px] font-black px-1.5 py-0.5 rounded-sm" title="Repeat Customer across multiple orders!">
                              REPEAT
                            </span>
                          )}
                        </div>
                        <div className="text-[11px] font-mono text-emerald-800 mt-0.5 flex items-center gap-1">
                          <MessageSquare className="w-3 h-3 text-emerald-600" />
                          <span>{order.whatsappPhone || 'No Phone'}</span>
                        </div>
                      </td>

                      {/* Order ID & Date */}
                      <td className="py-3 px-4 whitespace-nowrap">
                        <span className="font-semibold text-slate-800 block">{order.orderId}</span>
                        <span className="text-[11px] text-slate-500">{order.orderDate}</span>
                      </td>

                      {/* Items & Category */}
                      <td className="py-3 px-4 max-w-xs">
                        <span className="font-medium text-slate-800 line-clamp-1" title={order.items}>
                          {order.items}
                        </span>
                        <div className="flex items-center gap-1.5 mt-0.5">
                          <span className="text-[10px] text-slate-400">{order.category}</span>
                          {(() => {
                            const pClean = order.whatsappPhone ? order.whatsappPhone.replace(/[^\d]/g, '') : order.customerName;
                            const r = customerRecs.get(pClean)?.profile?.primaryRecommendation;
                            return r ? (
                              <span className="text-[9px] font-bold text-emerald-800 bg-emerald-50 border border-emerald-200/60 px-1 rounded-sm flex items-center gap-0.5" title={`AI Suggests: ${r.productName} at ${currencySymbol}${r.discountedPrice}`}>
                                <Sparkles className="w-2.5 h-2.5 text-amber-500" />
                                <span>Pair: {r.productName.split('(')[0]?.trim()}</span>
                              </span>
                            ) : null;
                          })()}
                        </div>
                      </td>

                      {/* Amount & Payment Method */}
                      <td className="py-3 px-4 whitespace-nowrap">
                        <div className="font-bold text-slate-900">
                          {currencySymbol} {order.totalAmountBDT.toLocaleString()}
                        </div>
                        <div className="mt-0.5">
                          {order.paymentMethod.includes('bKash') && (
                            <span className="bg-pink-100 text-pink-800 font-bold text-[10px] px-1.5 py-0.5 rounded-sm">
                              {order.paymentMethod}
                            </span>
                          )}
                          {order.paymentMethod.includes('Nagad') && (
                            <span className="bg-orange-100 text-orange-800 font-bold text-[10px] px-1.5 py-0.5 rounded-sm">
                              Nagad
                            </span>
                          )}
                          {order.paymentMethod.includes('COD') && (
                            <span className="bg-amber-100 text-amber-800 font-bold text-[10px] px-1.5 py-0.5 rounded-sm">
                              COD (Cash on Del.)
                            </span>
                          )}
                          {order.paymentMethod.includes('Bank') && (
                            <span className="bg-blue-100 text-blue-800 font-bold text-[10px] px-1.5 py-0.5 rounded-sm">
                              Bank Transfer
                            </span>
                          )}
                        </div>
                      </td>

                      {/* Advance Paid vs Due */}
                      <td className="py-3 px-4 whitespace-nowrap text-[11px]">
                        <div>
                          <span className="text-slate-400">Paid: </span>
                          <strong className="text-emerald-700">{currencySymbol} {order.advancePaidBDT}</strong>
                        </div>
                        <div>
                          <span className="text-slate-400">Due: </span>
                          <strong className={order.dueAmountBDT > 0 ? 'text-amber-800' : 'text-slate-400'}>
                            {currencySymbol} {order.dueAmountBDT}
                          </strong>
                        </div>
                      </td>

                      {/* District & Courier */}
                      <td className="py-3 px-4 whitespace-nowrap">
                        <div className="text-slate-800 font-medium">{order.deliveryDistrict}</div>
                        <div className="text-[10px] text-slate-500 flex items-center gap-1 mt-0.5">
                          <Truck className="w-3 h-3 text-slate-400" />
                          <span>{order.courierPartner}</span>
                          <span className="text-slate-400">({order.trackingNumber})</span>
                        </div>
                      </td>

                      {/* Delivery Status */}
                      <td className="py-3 px-4 whitespace-nowrap">
                        {order.deliveryStatus === 'Delivered' && (
                          <span className="inline-flex items-center gap-1 bg-emerald-100 text-emerald-800 text-[11px] font-bold px-2 py-0.5 rounded-full">
                            <CheckCircle2 className="w-3 h-3" />
                            <span>Delivered</span>
                          </span>
                        )}
                        {order.deliveryStatus === 'In Transit' && (
                          <span className="inline-flex items-center gap-1 bg-blue-100 text-blue-800 text-[11px] font-bold px-2 py-0.5 rounded-full">
                            <Truck className="w-3 h-3" />
                            <span>In Transit</span>
                          </span>
                        )}
                        {order.deliveryStatus === 'Pending Confirmation' && (
                          <span className="inline-flex items-center gap-1 bg-amber-100 text-amber-800 text-[11px] font-bold px-2 py-0.5 rounded-full">
                            <Clock className="w-3 h-3" />
                            <span>Pending</span>
                          </span>
                        )}
                        {order.deliveryStatus === 'RTO / Returned' && (
                          <span className="inline-flex items-center gap-1 bg-rose-100 text-rose-800 text-[11px] font-bold px-2 py-0.5 rounded-full" title={order.customerNotes || 'Parcel returned by courier'}>
                            <RotateCcw className="w-3 h-3" />
                            <span>RTO / Returned</span>
                          </span>
                        )}
                      </td>

                      {/* 1-Click WhatsApp Button & AI Offer */}
                      <td className="py-3 px-4 text-right whitespace-nowrap">
                        <div className="inline-flex items-center gap-1.5">
                          {(() => {
                            const pClean = order.whatsappPhone ? order.whatsappPhone.replace(/[^\d]/g, '') : order.customerName;
                            const r = customerRecs.get(pClean)?.profile?.primaryRecommendation;
                            return r ? (
                              <button
                                onClick={() => {
                                  setSelectedOrderForChat(order);
                                  setChatTemplate('personalized_offer');
                                }}
                                className="inline-flex items-center gap-1 px-2.5 py-1.5 bg-amber-50 hover:bg-amber-100 text-amber-900 border border-amber-300 rounded-lg text-xs font-bold transition-all shadow-2xs cursor-pointer"
                                title={`Send personalized offer: ${r.productName} (${currencySymbol}${r.discountedPrice})`}
                              >
                                <Sparkles className="w-3.5 h-3.5 text-amber-600" />
                                <span>AI Offer</span>
                              </button>
                            ) : null;
                          })()}
                          <button
                            onClick={() => setSelectedOrderForChat(order)}
                            className="inline-flex items-center gap-1.5 px-3 py-1.5 bg-emerald-600 hover:bg-emerald-700 text-white rounded-lg text-xs font-bold transition-all shadow-2xs hover:shadow-xs cursor-pointer"
                            title="Open WhatsApp message sender with pre-filled templates"
                          >
                            <MessageSquare className="w-3.5 h-3.5" />
                            <span>Chat</span>
                          </button>
                        </div>
                      </td>
                    </tr>
                  );
                })
              )}
            </tbody>
          </table>
        </div>
      </div>
      ) : (
        /* AI Personalized Product Suggestions & Offers Studio */
        <div className="space-y-6">
          {/* Header Banner */}
          <div className="bg-gradient-to-r from-emerald-900 via-teal-900 to-slate-900 rounded-2xl p-6 text-white shadow-sm border border-emerald-800">
            <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
              <div>
                <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-emerald-500/20 text-emerald-300 border border-emerald-400/30 text-xs font-bold uppercase tracking-wider mb-2">
                  <Sparkles className="w-3.5 h-3.5 text-amber-300" />
                  Next-Best-Product (NBP) & Segment Offer Engine
                </span>
                <h3 className="text-xl font-black text-white tracking-tight">
                  Personalized WhatsApp Cross-Sell Studio
                </h3>
                <p className="text-xs text-emerald-100/90 mt-1 max-w-2xl leading-relaxed">
                  Automatically pairs your customers’ purchase history with high-affinity complementary products, personalized promo codes, and ready-to-send WhatsApp pitch scripts in Bangla & English.
                </p>
              </div>

              {/* Quick metrics banner */}
              <div className="grid grid-cols-2 gap-3 shrink-0">
                <div className="bg-white/10 backdrop-blur-xs rounded-xl p-3 border border-white/15">
                  <span className="text-[10px] text-emerald-200 block font-semibold uppercase">Unique Shoppers</span>
                  <span className="text-lg font-black text-white">{customerRecs.size} Profiles</span>
                </div>
                <div className="bg-white/10 backdrop-blur-xs rounded-xl p-3 border border-white/15">
                  <span className="text-[10px] text-amber-200 block font-semibold uppercase">Potential Basket Uplift</span>
                  <span className="text-lg font-black text-amber-300">
                    {currencySymbol} {Array.from(customerRecs.values()).reduce((sum, c) => sum + (c.profile?.primaryRecommendation?.discountedPrice || 0), 0).toLocaleString()}
                  </span>
                </div>
              </div>
            </div>

            {/* Category Basket Synergy Guide */}
            <div className="mt-5 pt-4 border-t border-emerald-800/80 flex flex-wrap items-center gap-2 text-xs">
              <span className="text-[11px] font-bold text-emerald-300 uppercase tracking-wide">
                Top Basket Synergies:
              </span>
              <span className="bg-white/10 border border-white/15 px-2.5 py-1 rounded-lg text-emerald-100 flex items-center gap-1.5">
                <span>👗 Dhakai Jamdani Saree</span>
                <ArrowRight className="w-3 h-3 text-amber-300" />
                <strong className="text-white">Silk Katan Dupatta / Clutch (96%)</strong>
              </span>
              <span className="bg-white/10 border border-white/15 px-2.5 py-1 rounded-lg text-emerald-100 flex items-center gap-1.5">
                <span>👔 Festive Silk Panjabi</span>
                <ArrowRight className="w-3 h-3 text-amber-300" />
                <strong className="text-white">Full Cowhide Leather Wallet (92%)</strong>
              </span>
              <span className="bg-white/10 border border-white/15 px-2.5 py-1 rounded-lg text-emerald-100 flex items-center gap-1.5">
                <span>🍯 Sundarban Honey / Mustard Oil</span>
                <ArrowRight className="w-3 h-3 text-amber-300" />
                <strong className="text-white">Dinajpur Aromatic Rice (94%)</strong>
              </span>
            </div>
          </div>

          {/* Customer Recommendation Cards Grid */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {Array.from(customerRecs.entries()).map(([key, entry]) => {
              const rec = entry.profile?.primaryRecommendation;
              if (!rec) return null;
              const firstOrder = entry.orders[0];

              return (
                <div
                  key={key}
                  className="bg-white rounded-2xl border border-slate-200/90 shadow-2xs hover:shadow-xs transition-all p-4.5 flex flex-col justify-between"
                >
                  <div className="space-y-3">
                    {/* Header */}
                    <div className="flex items-start justify-between gap-2">
                      <div>
                        <h4 className="font-bold text-slate-900 text-sm">{entry.customerName}</h4>
                        <div className="text-[11px] text-emerald-700 font-mono flex items-center gap-1 mt-0.5">
                          <MessageSquare className="w-3 h-3" />
                          <span>{entry.whatsappPhone || 'No Phone'}</span>
                        </div>
                      </div>
                      <span className="bg-emerald-100 text-emerald-800 text-[10px] font-bold px-2 py-0.5 rounded-full shrink-0">
                        {entry.profile.persona.split('(')[0]?.trim()}
                      </span>
                    </div>

                    {/* Past Order Summary */}
                    <div className="text-[11px] bg-slate-50 border border-slate-200/70 rounded-xl p-2.5 space-y-1">
                      <div className="flex justify-between text-slate-500">
                        <span>Past Activity:</span>
                        <strong className="text-slate-800 font-medium">
                          {entry.orders.length} order{entry.orders.length > 1 ? 's' : ''} · {currencySymbol}{entry.totalSpend.toLocaleString()}
                        </strong>
                      </div>
                      <div className="text-slate-600 truncate">
                        <span className="text-slate-400">Bought: </span>
                        <span className="font-medium">{entry.orders[0]?.items}</span>
                      </div>
                    </div>

                    {/* Next-Best Recommendation Card */}
                    <div className="p-3.5 bg-gradient-to-br from-amber-50/70 to-emerald-50/50 border border-amber-200/80 rounded-xl space-y-2">
                      <div className="flex items-start justify-between gap-2">
                        <div>
                          <span className="text-[10px] font-bold text-amber-900 uppercase tracking-wide flex items-center gap-1">
                            <Sparkles className="w-3 h-3 text-amber-500" />
                            <span>Recommended Companion</span>
                          </span>
                          <h5 className="font-extrabold text-slate-900 text-xs mt-0.5">
                            {rec.productName}
                          </h5>
                          <span className="text-[10px] text-slate-500 block">
                            💡 {rec.recommendationReason}
                          </span>
                        </div>
                        <span className="text-[10px] bg-emerald-100 text-emerald-800 font-bold px-1.5 py-0.5 rounded-sm shrink-0">
                          {rec.affinityScorePct}% Match
                        </span>
                      </div>

                      {/* Pricing & Promo Code */}
                      <div className="pt-2 border-t border-amber-200/60 flex items-center justify-between text-xs">
                        <div>
                          <span className="font-black text-emerald-800 text-sm">
                            {currencySymbol}{rec.discountedPrice.toLocaleString()}
                          </span>
                          <span className="text-[10px] text-slate-400 line-through ml-1.5">
                            {currencySymbol}{rec.originalPrice.toLocaleString()}
                          </span>
                        </div>
                        <span className="text-[10px] font-mono font-bold bg-white px-2 py-0.5 rounded border border-amber-300 text-amber-900">
                          {rec.discountCode} (-{rec.discountPct}%)
                        </span>
                      </div>
                    </div>
                  </div>

                  {/* WhatsApp Action Buttons */}
                  <div className="pt-3 mt-3 border-t border-slate-100 flex items-center gap-2">
                    {firstOrder && (
                      <button
                        onClick={() => {
                          setSelectedOrderForChat(firstOrder);
                          setChatTemplate('personalized_offer');
                          setMessageLang('bn');
                        }}
                        className="flex-1 py-2 px-2.5 bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs rounded-xl transition-all shadow-2xs flex items-center justify-center gap-1.5 cursor-pointer"
                        title="Send personalized pitch on WhatsApp in Bangla"
                      >
                        <MessageSquare className="w-3.5 h-3.5" />
                        <span>Send Offer (বাংলা)</span>
                      </button>
                    )}

                    {firstOrder && (
                      <button
                        onClick={() => {
                          setSelectedOrderForChat(firstOrder);
                          setChatTemplate('personalized_offer');
                          setMessageLang('en');
                        }}
                        className="p-2 border border-slate-300 hover:bg-slate-100 text-slate-700 rounded-xl text-xs font-semibold cursor-pointer transition-colors"
                        title="Open in English"
                      >
                        EN
                      </button>
                    )}
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      )}

      {/* WhatsApp Message Preview & Dispatch Modal */}
      {selectedOrderForChat && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/60 backdrop-blur-xs p-4">
          <div className="bg-white rounded-2xl max-w-lg w-full shadow-2xl border border-slate-200 overflow-hidden">
            {/* Modal Header */}
            <div className="px-6 py-4 bg-emerald-800 text-white flex items-center justify-between">
              <div className="flex items-center gap-2">
                <div className="p-1.5 bg-emerald-700 rounded-lg">
                  <MessageSquare className="w-5 h-5 text-emerald-200" />
                </div>
                <div>
                  <h3 className="text-base font-bold text-white">Direct WhatsApp Dispatch</h3>
                  <p className="text-xs text-emerald-200">
                    Recipient: {selectedOrderForChat.customerName} ({selectedOrderForChat.whatsappPhone})
                  </p>
                </div>
              </div>
              <button
                onClick={() => setSelectedOrderForChat(null)}
                className="p-1.5 text-emerald-200 hover:text-white rounded-lg hover:bg-emerald-700 transition-colors cursor-pointer"
              >
                ✕
              </button>
            </div>

            {/* Modal Content */}
            <div className="p-6 space-y-4">
              <div>
                <div className="flex items-center justify-between mb-2">
                  <label className="text-xs font-bold text-slate-700">
                    Select Pre-filled Message Template
                  </label>
                  {/* Language Switcher */}
                  <div className="flex items-center bg-slate-100 p-0.5 rounded-lg border border-slate-200 text-[11px]">
                    <button
                      onClick={() => setMessageLang('en')}
                      className={`px-2.5 py-0.5 rounded-md font-bold transition-all cursor-pointer ${
                        messageLang === 'en'
                          ? 'bg-white text-emerald-800 shadow-2xs'
                          : 'text-slate-500 hover:text-slate-800'
                      }`}
                    >
                      English
                    </button>
                    <button
                      onClick={() => setMessageLang('bn')}
                      className={`px-2.5 py-0.5 rounded-md font-bold transition-all cursor-pointer ${
                        messageLang === 'bn'
                          ? 'bg-white text-emerald-800 shadow-2xs'
                          : 'text-slate-500 hover:text-slate-800'
                      }`}
                    >
                      BN (Bangla)
                    </button>
                  </div>
                </div>

                <div className="grid grid-cols-2 gap-2 text-xs">
                  <button
                    onClick={() => setChatTemplate('personalized_offer')}
                    className={`col-span-2 p-2.5 rounded-xl border text-left cursor-pointer transition-colors ${
                      chatTemplate === 'personalized_offer'
                        ? 'border-emerald-600 bg-emerald-50 text-emerald-900 font-bold'
                        : 'border-slate-200 hover:bg-slate-50 text-slate-700'
                    }`}
                  >
                    <span className="block font-bold flex items-center gap-1.5 text-emerald-800">
                      <Sparkles className="w-3.5 h-3.5 text-amber-500" />
                      <span>✨ AI Personalized Offer & Suggestion Pitch</span>
                    </span>
                    <span className="text-[10px] text-slate-500">
                      {messageLang === 'bn' ? 'আগের ক্রয়ের ভিত্তিতে সাজেস্টেড আইটেম ও স্পেশাল ছাড়' : 'Next-best complementary cross-sell pitch with custom code'}
                    </span>
                  </button>

                  <button
                    onClick={() => setChatTemplate('order_confirm')}
                    className={`p-2.5 rounded-xl border text-left cursor-pointer transition-colors ${
                      chatTemplate === 'order_confirm'
                        ? 'border-emerald-600 bg-emerald-50 text-emerald-900 font-bold'
                        : 'border-slate-200 hover:bg-slate-50 text-slate-700'
                    }`}
                  >
                    <span className="block font-bold">📦 Order Confirmation</span>
                    <span className="text-[10px] text-slate-500">
                      {messageLang === 'bn' ? 'অর্ডার কনফার্মেশন ও bKash রিকোয়েস্ট' : 'bKash advance fee request'}
                    </span>
                  </button>

                  <button
                    onClick={() => setChatTemplate('courier_dispatch')}
                    className={`p-2.5 rounded-xl border text-left cursor-pointer transition-colors ${
                      chatTemplate === 'courier_dispatch'
                        ? 'border-emerald-600 bg-emerald-50 text-emerald-900 font-bold'
                        : 'border-slate-200 hover:bg-slate-50 text-slate-700'
                    }`}
                  >
                    <span className="block font-bold">🚚 Courier Dispatched</span>
                    <span className="text-[10px] text-slate-500">
                      {messageLang === 'bn' ? 'কুরিয়ার বুকিং ও ট্র্যাকিং কোড' : 'Tracking ID & payable COD'}
                    </span>
                  </button>

                  <button
                    onClick={() => setChatTemplate('eid_offer')}
                    className={`p-2.5 rounded-xl border text-left cursor-pointer transition-colors ${
                      chatTemplate === 'eid_offer'
                        ? 'border-emerald-600 bg-emerald-50 text-emerald-900 font-bold'
                        : 'border-slate-200 hover:bg-slate-50 text-slate-700'
                    }`}
                  >
                    <span className="block font-bold">🎁 VIP Loyalist Offer</span>
                    <span className="text-[10px] text-slate-500">
                      {messageLang === 'bn' ? 'স্পেশাল লয়ালটি ভাউচার' : '15% repeat buyer discount'}
                    </span>
                  </button>

                  <button
                    onClick={() => setChatTemplate('review_request')}
                    className={`p-2.5 rounded-xl border text-left cursor-pointer transition-colors ${
                      chatTemplate === 'review_request'
                        ? 'border-emerald-600 bg-emerald-50 text-emerald-900 font-bold'
                        : 'border-slate-200 hover:bg-slate-50 text-slate-700'
                    }`}
                  >
                    <span className="block font-bold">💬 Review & Feedback</span>
                    <span className="text-[10px] text-slate-500">
                      {messageLang === 'bn' ? 'ডেলিভারি রিভিউ ও ছবি' : 'Post-delivery rating'}
                    </span>
                  </button>
                </div>
              </div>

              {/* Message Box */}
              <div>
                <div className="flex items-center justify-between mb-1.5">
                  <label className="text-xs font-bold text-slate-700">
                    Message Preview ({messageLang === 'en' ? 'English' : 'বাংলা'})
                  </label>
                  <span className="text-[10px] text-emerald-700 font-semibold bg-emerald-50 px-2 py-0.5 rounded-md border border-emerald-200/60">
                    Merge tags auto-filled
                  </span>
                </div>
                <div className="bg-slate-50 p-3.5 rounded-xl border border-slate-200 text-xs text-slate-800 whitespace-pre-wrap leading-relaxed max-h-48 overflow-y-auto font-sans">
                  {(() => {
                    const cKey = selectedOrderForChat.whatsappPhone
                      ? selectedOrderForChat.whatsappPhone.replace(/[^\d]/g, '')
                      : selectedOrderForChat.customerName;
                    const r = customerRecs.get(cKey)?.profile?.primaryRecommendation;

                    if (chatTemplate === 'personalized_offer' && r) {
                      return messageLang === 'en' ? r.pitchSnippetEn : r.pitchSnippetBn;
                    }

                    if (messageLang === 'en') {
                      if (chatTemplate === 'order_confirm') {
                        return (
                          <>
                            Hello {selectedOrderForChat.customerName}! 🌸
                            {'\n\n'}Thank you for shopping with us. Your order details:
                            {'\n'}📦 Items: {selectedOrderForChat.items}
                            {'\n'}💰 Total Amount: Tk {selectedOrderForChat.totalAmountBDT}
                            {'\n'}💳 Advance Received: Tk {selectedOrderForChat.advancePaidBDT}
                            {'\n'}💵 Due on Delivery (COD): Tk {selectedOrderForChat.dueAmountBDT}
                            {'\n\n'}Please reply to confirm your delivery address ({selectedOrderForChat.deliveryDistrict}) and phone number for dispatch. Thank you! ✨
                          </>
                        );
                      }
                      if (chatTemplate === 'courier_dispatch') {
                        return (
                          <>
                            Dear {selectedOrderForChat.customerName}, 🚚
                            {'\n\n'}Your parcel has been dispatched via {selectedOrderForChat.courierPartner}!
                            {'\n'}📍 Consignment / Tracking ID: {selectedOrderForChat.trackingNumber}
                            {'\n'}💵 Payable on Delivery (COD): Tk {selectedOrderForChat.dueAmountBDT}
                            {'\n\n'}The delivery rider will contact you within 24-48 hours. Feel free to message us if you need any assistance! 🛍️
                          </>
                        );
                      }
                      if (chatTemplate === 'eid_offer') {
                        return (
                          <>
                            Hello {selectedOrderForChat.customerName}! 🌟
                            {'\n\n'}As a valued VIP loyalist of our shop, enjoy an exclusive 15% discount on our new festive collection!
                            {'\n'}🎁 Promo Code: EIDVIP15
                            {'\n\n'}Browse our WhatsApp catalog and place your order before Eid stock runs out! 🌙✨
                          </>
                        );
                      }
                      if (chatTemplate === 'review_request') {
                        return (
                          <>
                            Hi {selectedOrderForChat.customerName}! 😊
                            {'\n\n'}We hope you received your parcel ({selectedOrderForChat.items}) and love it!
                            {'\n\n'}Could you share a brief review or photo with us? Your feedback means the world to our small local business! ❤️
                          </>
                        );
                      }
                    } else {
                      if (chatTemplate === 'order_confirm') {
                        return (
                          <>
                            আসসালামু আলাইকুম {selectedOrderForChat.customerName}! 🌸
                            {'\n\n'}আমাদের শপ থেকে আপনার অর্ডারটি রিসিভ করা হয়েছে:
                            {'\n'}📦 প্রোডাক্ট: {selectedOrderForChat.items}
                            {'\n'}💰 মোট মূল্য: Tk {selectedOrderForChat.totalAmountBDT}
                            {'\n'}💳 অ্যাডভান্স পেমেন্ট: Tk {selectedOrderForChat.advancePaidBDT}
                            {'\n'}💵 ক্যাশ অন ডেলিভারি বাকি: Tk {selectedOrderForChat.dueAmountBDT}
                            {'\n\n'}আপনার ঠিকানা ({selectedOrderForChat.deliveryDistrict}) এবং ফোন নম্বর নিশ্চিত করতে দয়া করে এই মেসেজের উত্তর দিন। ধন্যবাদ! ✨
                          </>
                        );
                      }
                      if (chatTemplate === 'courier_dispatch') {
                        return (
                          <>
                            প্রিয় {selectedOrderForChat.customerName}, 🚚
                            {'\n\n'}আপনার পার্সেলটি সফলভাবে {selectedOrderForChat.courierPartner} এ বুক করা হয়েছে!
                            {'\n'}📍 ট্র্যাকিং নাম্বার: {selectedOrderForChat.trackingNumber}
                            {'\n'}💵 বাকি অ্যামাউন্ট (COD): Tk {selectedOrderForChat.dueAmountBDT}
                            {'\n\n'}আগামী ২৪-৪৮ ঘণ্টার মধ্যে ডেলিভারি রাইডার আপনার সাথে যোগাযোগ করবেন। যেকোনো প্রয়োজনে আমাদের জানান। ধন্যবাদ! 🛍️
                          </>
                        );
                      }
                      if (chatTemplate === 'eid_offer') {
                        return (
                          <>
                            আসসালামু আলাইকুম {selectedOrderForChat.customerName}! 🌟
                            {'\n\n'}আমাদের প্রিয় লয়াল কাস্টমার হিসেবে আপনার জন্য নতুন কালেকশনে স্পেশাল ১৫% ছাড় ভাউচার!
                            {'\n'}🎁 ডিসকাউন্ট কোড: EIDVIP15
                            {'\n\n'}আমাদের ক্যাটালগ দেখতে বা অর্ডার করতে এখনই আমাদের জানান। অফারটি সীমিত সময়ের জন্য! 🌙✨
                          </>
                        );
                      }
                      if (chatTemplate === 'review_request') {
                        return (
                          <>
                            হ্যালো {selectedOrderForChat.customerName}! 😊
                            {'\n\n'}আশা করি আপনার পার্সেলটি ({selectedOrderForChat.items}) হাতে পেয়েছেন এবং ভালো লেগেছে! 🎁
                            {'\n\n'}আমাদের প্রডাক্ট এবং সার্ভিস সম্পর্কে আপনার মূল্যবান রিভিউ বা ছবি শেয়ার করলে আমরা অত্যন্ত কৃতজ্ঞ থাকবো! ❤️
                          </>
                        );
                      }
                    }
                    return null;
                  })()}
                </div>
              </div>

              {/* Action buttons */}
              <div className="pt-2 flex items-center justify-between gap-3">
                {(() => {
                  const cKey = selectedOrderForChat.whatsappPhone
                    ? selectedOrderForChat.whatsappPhone.replace(/[^\d]/g, '')
                    : selectedOrderForChat.customerName;
                  const r = customerRecs.get(cKey)?.profile?.primaryRecommendation;
                  const customText = chatTemplate === 'personalized_offer' && r
                    ? (messageLang === 'en' ? r.pitchSnippetEn : r.pitchSnippetBn)
                    : undefined;

                  const url = buildWhatsAppChatUrl(
                    selectedOrderForChat.whatsappPhone,
                    chatTemplate,
                    {
                      customerName: selectedOrderForChat.customerName,
                      items: selectedOrderForChat.items,
                      totalAmountBDT: selectedOrderForChat.totalAmountBDT,
                      advancePaidBDT: selectedOrderForChat.advancePaidBDT,
                      dueAmountBDT: selectedOrderForChat.dueAmountBDT,
                      trackingNumber: selectedOrderForChat.trackingNumber,
                      courierPartner: selectedOrderForChat.courierPartner,
                      promoCode: r?.discountCode || 'EIDVIP15',
                      discountPct: r?.discountPct || 15,
                      suggestedProduct: r?.productName,
                      discountedPrice: r?.discountedPrice,
                      customMessage: customText,
                      lang: messageLang,
                    }
                  );

                  return (
                    <>
                      <button
                        onClick={() => {
                          navigator.clipboard.writeText(url);
                          setCopiedLink(true);
                          setTimeout(() => setCopiedLink(false), 2000);
                        }}
                        className="px-3 py-2 border border-slate-300 hover:bg-slate-100 rounded-xl text-xs font-semibold text-slate-700 flex items-center gap-1.5 cursor-pointer transition-colors"
                      >
                        {copiedLink ? <Check className="w-4 h-4 text-emerald-600" /> : <Copy className="w-4 h-4 text-slate-500" />}
                        <span>{copiedLink ? 'Link Copied!' : 'Copy wa.me Link'}</span>
                      </button>

                      <a
                        href={url}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="px-4 py-2 bg-emerald-600 hover:bg-emerald-500 text-white rounded-xl text-xs font-extrabold flex items-center gap-2 shadow-sm transition-all cursor-pointer"
                      >
                        <Send className="w-4 h-4" />
                        <span>Launch WhatsApp Web / App</span>
                        <ExternalLink className="w-3.5 h-3.5 text-emerald-200" />
                      </a>
                    </>
                  );
                })()}
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
