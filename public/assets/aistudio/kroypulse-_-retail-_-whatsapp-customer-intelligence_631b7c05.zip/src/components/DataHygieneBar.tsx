import React, { useState } from 'react';
import { DataHygieneStats } from '../rfm/types';
import { ShieldCheck, ChevronDown, ChevronUp, CheckCircle2, UserCheck, Trash2, Smartphone, Users } from 'lucide-react';

interface DataHygieneBarProps {
  stats: DataHygieneStats;
}

export const DataHygieneBar: React.FC<DataHygieneBarProps> = ({ stats }) => {
  const [isExpanded, setIsExpanded] = useState(false);

  return (
    <div className="bg-white/90 backdrop-blur-xs border-b border-slate-200/80 text-xs">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-2">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
          {/* Left: Summary text with inline metrics */}
          <div className="flex items-center gap-2 flex-wrap text-slate-600">
            <span className="inline-flex items-center gap-1.5 font-semibold text-slate-800">
              <ShieldCheck className="w-4 h-4 text-emerald-600" />
              <span>Data Hygiene Audit</span>
            </span>
            <span className="hidden sm:inline text-slate-300">|</span>
            <div className="flex items-center gap-3 flex-wrap text-[11px] text-slate-600">
              <span>
                <strong className="text-slate-900">{stats.validIdentifiedRows.toLocaleString()}</strong> valid transactions
              </span>
              <span className="text-slate-300">·</span>
              <span className="text-emerald-700 bg-emerald-50 px-1.5 py-0.5 rounded font-medium">
                <strong>{stats.repeatGuestBuyersRecovered.toLocaleString()}</strong> repeat guests recovered
              </span>
              <span className="text-slate-300">·</span>
              <span className="text-slate-500">
                {(stats.cancelledRowsRemoved + stats.duplicateOrInvalidRowsRemoved).toLocaleString()} invalid filtered
              </span>
            </div>
          </div>

          {/* Right: Toggle details */}
          <button
            onClick={() => setIsExpanded(!isExpanded)}
            className="inline-flex items-center gap-1 text-[11px] font-medium text-slate-500 hover:text-slate-800 transition-colors self-start sm:self-auto cursor-pointer"
          >
            <span>{isExpanded ? 'Hide Details' : 'Audit Breakdown'}</span>
            {isExpanded ? <ChevronUp className="w-3.5 h-3.5" /> : <ChevronDown className="w-3.5 h-3.5" />}
          </button>
        </div>

        {/* Expandable Breakdown Drawer */}
        {isExpanded && (
          <div className="mt-3 pt-3 border-t border-slate-100 grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3 animate-in fade-in duration-150">
            <div className="bg-slate-50 rounded-lg p-2.5 border border-slate-200/60">
              <div className="flex items-center gap-1.5 text-slate-500 text-[10px] uppercase font-semibold">
                <Users className="w-3.5 h-3.5" /> Total Raw Ingested
              </div>
              <div className="text-base font-bold text-slate-900 mt-1">
                {stats.totalRawRows.toLocaleString()} <span className="text-[11px] font-normal text-slate-500">rows</span>
              </div>
              <p className="text-[10px] text-slate-400 mt-0.5">Original input transaction lines</p>
            </div>

            <div className="bg-emerald-50/60 rounded-lg p-2.5 border border-emerald-200/60">
              <div className="flex items-center gap-1.5 text-emerald-700 text-[10px] uppercase font-semibold">
                <UserCheck className="w-3.5 h-3.5 text-emerald-600" /> Cleaned & Validated
              </div>
              <div className="text-base font-bold text-emerald-900 mt-1">
                {stats.validIdentifiedRows.toLocaleString()} <span className="text-[11px] font-normal text-emerald-700">active</span>
              </div>
              <p className="text-[10px] text-emerald-600/80 mt-0.5">Positive quantity & revenue orders</p>
            </div>

            <div className="bg-indigo-50/60 rounded-lg p-2.5 border border-indigo-200/60">
              <div className="flex items-center gap-1.5 text-indigo-700 text-[10px] uppercase font-semibold">
                <Smartphone className="w-3.5 h-3.5 text-indigo-600" /> Guest Identities Stitched
              </div>
              <div className="text-base font-bold text-indigo-900 mt-1">
                {stats.repeatGuestBuyersRecovered.toLocaleString()} <span className="text-[11px] font-normal text-indigo-700">recovered</span>
              </div>
              <p className="text-[10px] text-indigo-600/80 mt-0.5">Unified across E.164 phone & email</p>
            </div>

            <div className="bg-rose-50/60 rounded-lg p-2.5 border border-rose-200/60">
              <div className="flex items-center gap-1.5 text-rose-700 text-[10px] uppercase font-semibold">
                <Trash2 className="w-3.5 h-3.5 text-rose-600" /> Filtered Outliers
              </div>
              <div className="text-base font-bold text-rose-900 mt-1">
                {(stats.cancelledRowsRemoved + stats.duplicateOrInvalidRowsRemoved).toLocaleString()} <span className="text-[11px] font-normal text-rose-700">excluded</span>
              </div>
              <p className="text-[10px] text-rose-600/80 mt-0.5">{stats.cancelledRowsRemoved} cancelled / returns, {stats.duplicateOrInvalidRowsRemoved} empty keys</p>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
