import {
  RawTransaction,
  ColumnMapping,
  CleanedTransaction,
  DataHygieneStats,
} from './types';

/**
 * Normalizes phone numbers across Bangladeshi (+880), UK (+44), US (+1), and generic formats.
 * Removes spaces, dashes, plus signs, brackets, and uniformizes BD mobile 01X numbers.
 */
export function normalizePhoneNumber(rawPhone?: any): string | undefined {
  if (rawPhone === undefined || rawPhone === null) return undefined;
  const str = String(rawPhone).trim();
  if (!str || str.toLowerCase() === 'nan' || str.toLowerCase() === 'null') return undefined;

  // Remove non-digit characters except leading plus
  let cleaned = str.replace(/[^\d+]/g, '');

  // Strip international prefix for Bangladesh e.g. +88017... or 88017... or 0088017...
  if (cleaned.startsWith('+880')) {
    cleaned = '0' + cleaned.substring(4);
  } else if (cleaned.startsWith('00880')) {
    cleaned = '0' + cleaned.substring(5);
  } else if (cleaned.startsWith('880')) {
    cleaned = '0' + cleaned.substring(3);
  } else if (cleaned.startsWith('+')) {
    cleaned = cleaned.substring(1);
  }

  // If only digits remain and length is sensible (at least 7 digits)
  if (/^\d{7,15}$/.test(cleaned)) {
    return cleaned;
  }

  return cleaned.length > 5 ? cleaned : undefined;
}

/**
 * Normalizes email address
 */
export function normalizeEmail(rawEmail?: any): string | undefined {
  if (rawEmail === undefined || rawEmail === null) return undefined;
  const str = String(rawEmail).trim().toLowerCase();
  if (!str || str === 'nan' || str === 'null' || !str.includes('@')) return undefined;
  return str;
}

/**
 * Auto-detects columns from raw dataset headers using fuzzy keyword matching
 */
export function autoDetectColumnMapping(headers: string[]): ColumnMapping {
  const findMatch = (keywords: string[]): string => {
    for (const kw of keywords) {
      const match = headers.find((h) =>
        h.toLowerCase().replace(/[^a-z0-9]/g, '').includes(kw.toLowerCase().replace(/[^a-z0-9]/g, ''))
      );
      if (match) return match;
    }
    return '';
  };

  const orderIdCol = findMatch(['invoiceno', 'invoice_no', 'orderid', 'order_id', 'receipt', 'invoice', 'id']);
  const timestampCol = findMatch(['invoicedate', 'invoice_date', 'orderdate', 'order_date', 'created_at', 'date', 'timestamp']);
  const customerCol = findMatch(['customerid', 'customer_id', 'userid', 'user_id', 'client_id', 'account_id']);
  const phoneCol = findMatch(['phone', 'mobile', 'whatsapp', 'cell', 'contact_no', 'telephone', 'ph']);
  const emailCol = findMatch(['email', 'customer_email', 'mail', 'user_email']);
  const productCol = findMatch(['stockcode', 'stock_code', 'product_id', 'item_code', 'sku', 'description', 'product_name', 'item_name']);
  
  const quantityCol = findMatch(['quantity', 'qty', 'count', 'units', 'pieces']);
  const unitPriceCol = findMatch(['unitprice', 'unit_price', 'price', 'rate', 'item_price']);
  const totalAmountCol = findMatch(['totalamount', 'total_amount', 'total', 'order_total', 'amount', 'grand_total', 'subtotal']);

  const hasQtyAndPrice = Boolean(quantityCol && unitPriceCol);
  const revenueMode: 'quantity_price' | 'total_amount' = hasQtyAndPrice || !totalAmountCol ? 'quantity_price' : 'total_amount';

  return {
    orderIdCol: orderIdCol || headers[0] || '',
    timestampCol: timestampCol || headers[1] || '',
    customerCol: customerCol || '',
    phoneCol: phoneCol || '',
    emailCol: emailCol || '',
    productCol: productCol || '',
    revenueMode,
    quantityCol: quantityCol || '',
    unitPriceCol: unitPriceCol || '',
    totalAmountCol: totalAmountCol || '',
  };
}

/**
 * Parses raw dates into valid JavaScript Date objects. Handles ISO strings, timestamps, DD/MM/YYYY, MM/DD/YYYY.
 */
export function parseDate(val: any): Date | null {
  if (!val) return null;
  if (val instanceof Date && !isNaN(val.getTime())) return val;

  const str = String(val).trim();
  // Try direct parse
  let d = new Date(str);
  if (!isNaN(d.getTime())) return d;

  // Try DD/MM/YYYY HH:mm or MM/DD/YYYY
  const parts = str.split(/[ /:\-T]/).filter(Boolean);
  if (parts.length >= 3) {
    const p0 = parseInt(parts[0], 10);
    const p1 = parseInt(parts[1], 10);
    const p2 = parseInt(parts[2], 10);

    // If p2 is 4 digits (year at end)
    if (p2 > 1000) {
      // If p0 > 12, then DD/MM/YYYY
      if (p0 > 12) {
        d = new Date(p2, p1 - 1, p0);
      } else {
        // Assume MM/DD/YYYY or DD/MM/YYYY
        d = new Date(p2, p0 - 1, p1);
      }
      if (!isNaN(d.getTime())) return d;
    }
  }

  return null;
}

/**
 * Zero-Account Guest Identity Stitcher & Data Hygiene Pipeline
 */
export function stitchAndCleanData(
  rows: RawTransaction[],
  mapping: ColumnMapping
): {
  cleanedRows: CleanedTransaction[];
  stats: DataHygieneStats;
} {
  let cancelledCount = 0;
  let invalidCount = 0;
  const cleanedRows: CleanedTransaction[] = [];

  for (let i = 0; i < rows.length; i++) {
    const r = rows[i];
    const rawOrderId = r[mapping.orderIdCol];
    if (rawOrderId === undefined || rawOrderId === null || String(rawOrderId).trim() === '') {
      invalidCount++;
      continue;
    }

    const orderIdStr = String(rawOrderId).trim();
    const isCancelFlag =
      orderIdStr.toUpperCase().startsWith('C') ||
      String(r.status || '').toLowerCase().includes('cancel') ||
      String(r.customer_name || '').toLowerCase().includes('cancel') ||
      String(r.Description || '').toLowerCase().includes('cancel');

    // Parse date
    const parsedDate = parseDate(r[mapping.timestampCol]);
    if (!parsedDate) {
      invalidCount++;
      continue;
    }

    // Revenue calculation
    let totalAmount = 0;
    let qty = 1;
    let unitPrice = 0;

    if (mapping.revenueMode === 'quantity_price') {
      qty = parseFloat(r[mapping.quantityCol]);
      unitPrice = parseFloat(r[mapping.unitPriceCol]);

      if (isNaN(qty) || isNaN(unitPrice)) {
        invalidCount++;
        continue;
      }

      if (isCancelFlag || qty < 0 || unitPrice < 0) {
        cancelledCount++;
        continue;
      }
      if (qty === 0 || unitPrice === 0) {
        invalidCount++;
        continue;
      }
      totalAmount = qty * unitPrice;
    } else {
      totalAmount = parseFloat(r[mapping.totalAmountCol]);
      if (isNaN(totalAmount)) {
        invalidCount++;
        continue;
      }

      if (isCancelFlag || totalAmount < 0) {
        cancelledCount++;
        continue;
      }
      if (totalAmount === 0) {
        invalidCount++;
        continue;
      }
      unitPrice = totalAmount;
    }

    // Extract identifiers
    let rawCustId = mapping.customerCol ? r[mapping.customerCol] : undefined;
    let custIdStr = rawCustId !== undefined && rawCustId !== null ? String(rawCustId).trim() : '';
    if (custIdStr.toLowerCase() === 'nan' || custIdStr.toLowerCase() === 'null' || custIdStr === '') {
      custIdStr = '';
    }

    const normPhone = mapping.phoneCol ? normalizePhoneNumber(r[mapping.phoneCol]) : undefined;
    const normEmail = mapping.emailCol ? normalizeEmail(r[mapping.emailCol]) : undefined;

    // Unified customer key resolution priority chain:
    // 1. CustomerID (if present)
    // 2. Normalized Phone
    // 3. Normalized Email
    // 4. Guest fallback to order ID
    let unifiedKey = '';
    let isGuest = false;

    if (custIdStr) {
      unifiedKey = `cust_${custIdStr}`;
    } else if (normPhone) {
      unifiedKey = `phone_${normPhone}`;
      isGuest = true;
    } else if (normEmail) {
      unifiedKey = `email_${normEmail}`;
      isGuest = true;
    } else {
      unifiedKey = `guest_order_${orderIdStr}`;
      isGuest = true;
    }

    const sku = mapping.productCol ? String(r[mapping.productCol] || `sku_${orderIdStr}`).trim() : `order_${orderIdStr}`;

    cleanedRows.push({
      orderId: orderIdStr,
      timestamp: parsedDate,
      dateStr: parsedDate.toISOString().slice(0, 10),
      customerId: custIdStr || undefined,
      phone: normPhone,
      normalizedPhone: normPhone,
      email: normEmail,
      normalizedEmail: normEmail,
      unifiedKey,
      isGuest,
      sku,
      quantity: qty,
      unitPrice,
      totalAmount,
    });
  }

  // Count repeat guest buyers recovered via phone/email
  // (Customers with isGuest = true whose unifiedKey appears across multiple distinct orderIds)
  const ordersByKey = new Map<string, Set<string>>();
  const guestKeys = new Set<string>();
  const registeredKeys = new Set<string>();

  for (const row of cleanedRows) {
    if (!ordersByKey.has(row.unifiedKey)) {
      ordersByKey.set(row.unifiedKey, new Set());
    }
    ordersByKey.get(row.unifiedKey)!.add(row.orderId);

    if (row.isGuest) {
      guestKeys.add(row.unifiedKey);
    } else {
      registeredKeys.add(row.unifiedKey);
    }
  }

  let repeatGuestBuyersRecovered = 0;
  for (const gKey of guestKeys) {
    const orderSet = ordersByKey.get(gKey);
    if (orderSet && orderSet.size >= 2) {
      // It's a guest customer who made repeat orders identified by phone or email!
      repeatGuestBuyersRecovered++;
    }
  }

  const uniqueCustomers = ordersByKey.size;
  const guestOnlyCount = guestKeys.size;
  const registeredUserCount = registeredKeys.size;
  const guestSharePct = uniqueCustomers > 0 ? (guestOnlyCount / uniqueCustomers) * 100 : 0;

  const stats: DataHygieneStats = {
    totalRawRows: rows.length,
    validIdentifiedRows: cleanedRows.length,
    cancelledRowsRemoved: cancelledCount,
    duplicateOrInvalidRowsRemoved: invalidCount,
    uniqueCustomers,
    repeatGuestBuyersRecovered,
    guestOnlyCount,
    registeredUserCount,
    guestSharePct,
  };

  return { cleanedRows, stats };
}
